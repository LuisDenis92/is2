--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO roberto;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO roberto;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO roberto;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO roberto;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    codename character varying(100) NOT NULL,
    content_type_id integer NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO roberto;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO roberto;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    direccion text NOT NULL,
    telefono character varying(15),
    cliente_id integer
);


ALTER TABLE public.auth_user OWNER TO roberto;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO roberto;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO roberto;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO roberto;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_roles; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_user_roles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    rol_id integer NOT NULL
);


ALTER TABLE public.auth_user_roles OWNER TO roberto;

--
-- Name: auth_user_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_user_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_roles_id_seq OWNER TO roberto;

--
-- Name: auth_user_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_user_roles_id_seq OWNED BY auth_user_roles.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO roberto;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO roberto;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO roberto;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO roberto;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO roberto;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO roberto;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO roberto;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO roberto;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO roberto;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO roberto;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO roberto;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: sgpa_actividad; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_actividad (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    estado_1 character varying(5) NOT NULL,
    estado_2 character varying(5) NOT NULL,
    estado_3 character varying(5) NOT NULL,
    orden integer NOT NULL
);


ALTER TABLE public.sgpa_actividad OWNER TO roberto;

--
-- Name: sgpa_actividad_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_actividad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_actividad_id_seq OWNER TO roberto;

--
-- Name: sgpa_actividad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_actividad_id_seq OWNED BY sgpa_actividad.id;


--
-- Name: sgpa_cliente; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_cliente (
    id integer NOT NULL,
    nombre character varying(32) NOT NULL,
    direccion character varying(70) NOT NULL,
    telefono character varying(70) NOT NULL,
    observacion text NOT NULL,
    correo character varying(70) NOT NULL,
    estado character varying(20) NOT NULL
);


ALTER TABLE public.sgpa_cliente OWNER TO roberto;

--
-- Name: sgpa_cliente_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_cliente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_cliente_id_seq OWNER TO roberto;

--
-- Name: sgpa_cliente_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_cliente_id_seq OWNED BY sgpa_cliente.id;


--
-- Name: sgpa_equipo; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_equipo (
    id integer NOT NULL,
    hora integer NOT NULL,
    proyecto_id integer,
    rol_id integer,
    usuario_id integer NOT NULL
);


ALTER TABLE public.sgpa_equipo OWNER TO roberto;

--
-- Name: sgpa_equipo_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_equipo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_equipo_id_seq OWNER TO roberto;

--
-- Name: sgpa_equipo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_equipo_id_seq OWNED BY sgpa_equipo.id;


--
-- Name: sgpa_files; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_files (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    dato bytea NOT NULL
);


ALTER TABLE public.sgpa_files OWNER TO roberto;

--
-- Name: sgpa_files_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_files_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_files_id_seq OWNER TO roberto;

--
-- Name: sgpa_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_files_id_seq OWNED BY sgpa_files.id;


--
-- Name: sgpa_flujo; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_flujo (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    descripcion character varying(200) NOT NULL,
    cantidad integer NOT NULL
);


ALTER TABLE public.sgpa_flujo OWNER TO roberto;

--
-- Name: sgpa_flujo_actividades; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_flujo_actividades (
    id integer NOT NULL,
    flujo_id integer NOT NULL,
    actividad_id integer NOT NULL
);


ALTER TABLE public.sgpa_flujo_actividades OWNER TO roberto;

--
-- Name: sgpa_flujo_actividades_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_flujo_actividades_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_flujo_actividades_id_seq OWNER TO roberto;

--
-- Name: sgpa_flujo_actividades_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_flujo_actividades_id_seq OWNED BY sgpa_flujo_actividades.id;


--
-- Name: sgpa_flujo_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_flujo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_flujo_id_seq OWNER TO roberto;

--
-- Name: sgpa_flujo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_flujo_id_seq OWNED BY sgpa_flujo.id;


--
-- Name: sgpa_historia; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_historia (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    usuario character varying(60) NOT NULL,
    fecha character varying(50) NOT NULL,
    descripcion character varying(200) NOT NULL,
    hu_id integer NOT NULL
);


ALTER TABLE public.sgpa_historia OWNER TO roberto;

--
-- Name: sgpa_historia_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_historia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_historia_id_seq OWNER TO roberto;

--
-- Name: sgpa_historia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_historia_id_seq OWNED BY sgpa_historia.id;


--
-- Name: sgpa_hu; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_hu (
    id integer NOT NULL,
    nombre character varying(32) NOT NULL,
    observacion text NOT NULL,
    valornegocio integer NOT NULL,
    valortecnico integer NOT NULL,
    hora integer NOT NULL,
    estadorevision character varying(20) NOT NULL,
    estadodesarrolllo character varying(20) NOT NULL,
    estadoflujo character varying(20) NOT NULL,
    actividad_id integer,
    flujo_id integer,
    proyecto_id integer,
    responsable_id integer,
    horat integer NOT NULL,
    CONSTRAINT sgpa_hu_hora_check CHECK ((hora >= 0)),
    CONSTRAINT sgpa_hu_horat_check CHECK ((horat >= 0))
);


ALTER TABLE public.sgpa_hu OWNER TO roberto;

--
-- Name: sgpa_hu_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_hu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_hu_id_seq OWNER TO roberto;

--
-- Name: sgpa_hu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_hu_id_seq OWNED BY sgpa_hu.id;


--
-- Name: sgpa_permiso; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_permiso (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    descripcion character varying(120) NOT NULL,
    tipo character varying(8) NOT NULL
);


ALTER TABLE public.sgpa_permiso OWNER TO roberto;

--
-- Name: sgpa_permiso_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_permiso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_permiso_id_seq OWNER TO roberto;

--
-- Name: sgpa_permiso_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_permiso_id_seq OWNED BY sgpa_permiso.id;


--
-- Name: sgpa_proyecto; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_proyecto (
    id integer NOT NULL,
    "fechaInicio" character varying(20) NOT NULL,
    "fechaFin" character varying(20) NOT NULL,
    "fechaMod" character varying(20) NOT NULL,
    nombre character varying(32) NOT NULL,
    estado character varying(20) NOT NULL,
    cliente_id integer NOT NULL,
    lider_id integer
);


ALTER TABLE public.sgpa_proyecto OWNER TO roberto;

--
-- Name: sgpa_proyecto_flujo; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_proyecto_flujo (
    id integer NOT NULL,
    proyecto_id integer NOT NULL,
    flujo_id integer NOT NULL
);


ALTER TABLE public.sgpa_proyecto_flujo OWNER TO roberto;

--
-- Name: sgpa_proyecto_flujo_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_proyecto_flujo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_proyecto_flujo_id_seq OWNER TO roberto;

--
-- Name: sgpa_proyecto_flujo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_proyecto_flujo_id_seq OWNED BY sgpa_proyecto_flujo.id;


--
-- Name: sgpa_proyecto_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_proyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_proyecto_id_seq OWNER TO roberto;

--
-- Name: sgpa_proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_proyecto_id_seq OWNED BY sgpa_proyecto.id;


--
-- Name: sgpa_rol; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_rol (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    descripcion character varying(120) NOT NULL,
    tipo character varying(8) NOT NULL
);


ALTER TABLE public.sgpa_rol OWNER TO roberto;

--
-- Name: sgpa_rol_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_rol_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_rol_id_seq OWNER TO roberto;

--
-- Name: sgpa_rol_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_rol_id_seq OWNED BY sgpa_rol.id;


--
-- Name: sgpa_rol_permisos; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_rol_permisos (
    id integer NOT NULL,
    rol_id integer NOT NULL,
    permiso_id integer NOT NULL
);


ALTER TABLE public.sgpa_rol_permisos OWNER TO roberto;

--
-- Name: sgpa_rol_permisos_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_rol_permisos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_rol_permisos_id_seq OWNER TO roberto;

--
-- Name: sgpa_rol_permisos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_rol_permisos_id_seq OWNED BY sgpa_rol_permisos.id;


--
-- Name: sgpa_sprint; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_sprint (
    id integer NOT NULL,
    duracion integer NOT NULL,
    "fechaInicio" character varying(50) NOT NULL,
    "fechaFin" character varying(50) NOT NULL,
    nombre character varying(60) NOT NULL,
    estado character varying(20) NOT NULL,
    proyecto_id integer
);


ALTER TABLE public.sgpa_sprint OWNER TO roberto;

--
-- Name: sgpa_sprint_hu; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_sprint_hu (
    id integer NOT NULL,
    sprint_id integer NOT NULL,
    hu_id integer NOT NULL
);


ALTER TABLE public.sgpa_sprint_hu OWNER TO roberto;

--
-- Name: sgpa_sprint_hu_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_sprint_hu_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_sprint_hu_id_seq OWNER TO roberto;

--
-- Name: sgpa_sprint_hu_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_sprint_hu_id_seq OWNED BY sgpa_sprint_hu.id;


--
-- Name: sgpa_sprint_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_sprint_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_sprint_id_seq OWNER TO roberto;

--
-- Name: sgpa_sprint_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_sprint_id_seq OWNED BY sgpa_sprint.id;


--
-- Name: sgpa_trabajo; Type: TABLE; Schema: public; Owner: roberto; Tablespace: 
--

CREATE TABLE sgpa_trabajo (
    id integer NOT NULL,
    nombre character varying(60) NOT NULL,
    horas integer NOT NULL,
    fecha character varying(60) NOT NULL,
    nota text NOT NULL,
    actor character varying(60) NOT NULL,
    filename character varying(60),
    size integer,
    flujo character varying(60),
    actividad character varying(60),
    estado character varying(60),
    sprint character varying(60),
    archivo_id integer,
    hu_id integer NOT NULL,
    CONSTRAINT sgpa_trabajo_horas_check CHECK ((horas >= 0))
);


ALTER TABLE public.sgpa_trabajo OWNER TO roberto;

--
-- Name: sgpa_trabajo_id_seq; Type: SEQUENCE; Schema: public; Owner: roberto
--

CREATE SEQUENCE sgpa_trabajo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sgpa_trabajo_id_seq OWNER TO roberto;

--
-- Name: sgpa_trabajo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: roberto
--

ALTER SEQUENCE sgpa_trabajo_id_seq OWNED BY sgpa_trabajo.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_roles ALTER COLUMN id SET DEFAULT nextval('auth_user_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_actividad ALTER COLUMN id SET DEFAULT nextval('sgpa_actividad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_cliente ALTER COLUMN id SET DEFAULT nextval('sgpa_cliente_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo ALTER COLUMN id SET DEFAULT nextval('sgpa_equipo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_files ALTER COLUMN id SET DEFAULT nextval('sgpa_files_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo ALTER COLUMN id SET DEFAULT nextval('sgpa_flujo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo_actividades ALTER COLUMN id SET DEFAULT nextval('sgpa_flujo_actividades_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_historia ALTER COLUMN id SET DEFAULT nextval('sgpa_historia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu ALTER COLUMN id SET DEFAULT nextval('sgpa_hu_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_permiso ALTER COLUMN id SET DEFAULT nextval('sgpa_permiso_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto ALTER COLUMN id SET DEFAULT nextval('sgpa_proyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto_flujo ALTER COLUMN id SET DEFAULT nextval('sgpa_proyecto_flujo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol ALTER COLUMN id SET DEFAULT nextval('sgpa_rol_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol_permisos ALTER COLUMN id SET DEFAULT nextval('sgpa_rol_permisos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint ALTER COLUMN id SET DEFAULT nextval('sgpa_sprint_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint_hu ALTER COLUMN id SET DEFAULT nextval('sgpa_sprint_hu_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_trabajo ALTER COLUMN id SET DEFAULT nextval('sgpa_trabajo_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_permission (id, name, codename, content_type_id) FROM stdin;
1	Can add permission	add_permission	1
2	Can change permission	change_permission	1
3	Can delete permission	delete_permission	1
4	Can add group	add_group	2
5	Can change group	change_group	2
6	Can delete group	delete_group	2
7	Can add user	add_user	3
8	Can change user	change_user	3
9	Can delete user	delete_user	3
10	Can add content type	add_contenttype	4
11	Can change content type	change_contenttype	4
12	Can delete content type	delete_contenttype	4
13	Can add session	add_session	5
14	Can change session	change_session	5
15	Can delete session	delete_session	5
16	Can add site	add_site	6
17	Can change site	change_site	6
18	Can delete site	delete_site	6
19	Can add log entry	add_logentry	7
20	Can change log entry	change_logentry	7
21	Can delete log entry	delete_logentry	7
22	Can add permiso	add_permiso	8
23	Can change permiso	change_permiso	8
24	Can delete permiso	delete_permiso	8
25	Can add actividad	add_actividad	9
26	Can change actividad	change_actividad	9
27	Can delete actividad	delete_actividad	9
28	Can add flujo	add_flujo	10
29	Can change flujo	change_flujo	10
30	Can delete flujo	delete_flujo	10
31	Can add cliente	add_cliente	11
32	Can change cliente	change_cliente	11
33	Can delete cliente	delete_cliente	11
34	Can add rol	add_rol	12
35	Can change rol	change_rol	12
36	Can delete rol	delete_rol	12
37	Can add proyecto	add_proyecto	13
38	Can change proyecto	change_proyecto	13
39	Can delete proyecto	delete_proyecto	13
40	Can add hu	add_hu	14
41	Can change hu	change_hu	14
42	Can delete hu	delete_hu	14
43	Can add sprint	add_sprint	15
44	Can change sprint	change_sprint	15
45	Can delete sprint	delete_sprint	15
46	Can add equipo	add_equipo	16
47	Can change equipo	change_equipo	16
48	Can delete equipo	delete_equipo	16
49	Can add historia	add_historia	17
50	Can change historia	change_historia	17
51	Can delete historia	delete_historia	17
52	Can add files	add_files	18
53	Can change files	change_files	18
54	Can delete files	delete_files	18
55	Can add trabajo	add_trabajo	19
56	Can change trabajo	change_trabajo	19
57	Can delete trabajo	delete_trabajo	19
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_permission_id_seq', 57, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined, direccion, telefono, cliente_id) FROM stdin;
3	pbkdf2_sha256$12000$X289eJOqZo8i$f8caQ7sguSQPGuB1kCxBejBOJGqYNIZkelr9oDvKMXY=	2015-05-30 07:03:21.142402+02	f	roberto				f	t	2015-05-30 07:03:21.142402+02		\N	\N
5	pbkdf2_sha256$12000$vaw8JUHp4tJD$z6Cm1Q4SdLnb8F5dwqF1DjQHZFT3gkryS2wCcSEY6HM=	2015-05-30 07:03:21.275768+02	f	pepe				f	t	2015-05-30 07:03:21.275768+02		\N	\N
6	pbkdf2_sha256$12000$wn0zwGbuG89k$CCSD02w/OoFkC3FNW4E9AgjYj14eCcuSo1tJ67jrpMY=	2015-05-30 07:03:21.331252+02	f	juan				f	t	2015-05-30 07:03:21.331252+02		\N	\N
8	pbkdf2_sha256$15000$0Fl1KvODYGTV$0zYHUnSEC8DuQdpdKKBUXsGAnCQjBWBL8vAAGGdlKIs=	2015-06-20 11:51:18.175156+02	f	pedro				f	t	2015-06-08 20:02:25.906281+02			\N
1	pbkdf2_sha256$15000$fVXOncaSdfAv$aRAu9gatRimkKvzjYe/aL8Q9lAvJTLT1DonqOUTbc0E=	2015-06-20 11:51:50.51519+02	f	admin				f	t	2015-05-30 07:03:21.003619+02		\N	\N
7	pbkdf2_sha256$15000$PEn1f4UVQCMn$EOkYAlKT8sIfZNFO0VDohwkTsT4c2IiGSyZiGxoJVBo=	2015-06-20 12:03:03.478043+02	f	luis				f	t	2015-06-08 20:02:12.072445+02			\N
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_user_id_seq', 8, true);


--
-- Data for Name: auth_user_roles; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_user_roles (id, user_id, rol_id) FROM stdin;
2	1	1
4	7	4
\.


--
-- Name: auth_user_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_user_roles_id_seq', 4, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	user	auth	user
4	content type	contenttypes	contenttype
5	session	sessions	session
6	site	sites	site
7	log entry	admin	logentry
8	permiso	sgpa	permiso
9	actividad	sgpa	actividad
10	flujo	sgpa	flujo
11	cliente	sgpa	cliente
12	rol	sgpa	rol
13	proyecto	sgpa	proyecto
14	hu	sgpa	hu
15	sprint	sgpa	sprint
16	equipo	sgpa	equipo
17	historia	sgpa	historia
18	files	sgpa	files
19	trabajo	sgpa	trabajo
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('django_content_type_id_seq', 19, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2015-06-08 17:18:22.104174+02
2	auth	0001_initial	2015-06-08 17:18:22.740912+02
3	admin	0001_initial	2015-06-08 17:18:22.974922+02
4	sgpa	0001_initial	2015-06-08 17:18:27.163633+02
5	auth	0002_auto_20150608_1000	2015-06-08 17:18:29.298995+02
6	sessions	0001_initial	2015-06-08 17:18:29.522949+02
7	sites	0001_initial	2015-06-08 17:18:29.589784+02
8	sgpa	0002_auto_20150620_0410	2015-06-20 11:10:51.132659+02
9	sgpa	0003_auto_20150620_0433	2015-06-20 11:33:25.446084+02
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('django_migrations_id_seq', 9, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
8b4a7c3skq4ppijtx9s6qmzl35u65qca	M2JlNmFjMmYwODRlYzI4MGNiZmFiM2E0Y2U4YTNjNDQwYTg5YTE4MTp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6MX0=	2015-06-13 14:17:28.691802+02
k93zezpk7cajmf6125d81t7vhuaqf97z	NTY0YzVlOWNkMWQyOWNjNTlkMGNlNzgxZDk0M2E5YTlhYzcxODM4YTp7Il9hdXRoX3VzZXJfaGFzaCI6ImE1ZWVmOTUzZDU2NmJiYTJkZmM4YjhmZTg4MmFhYTcyOTViMTg1YmIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjF9	2015-07-04 11:51:50.526388+02
77gi0qsgar1atz2nba5n05d9x2smop5r	YjJkYThlMTM2ODE5MzlkMzkzYjQyOGQzY2EzZmEyNjBjNjA0ZTQ3OTp7Il9hdXRoX3VzZXJfaGFzaCI6ImIzNmU4ZjQ5YmQ1YzJmNDVkOWVmOGI3ZWYwM2ZhODAzZTQ0ZDdjYzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOjd9	2015-07-04 12:03:03.489396+02
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: sgpa_actividad; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_actividad (id, nombre, estado_1, estado_2, estado_3, orden) FROM stdin;
1	act1	TO_DO	DOING	DONE	1
2	act2	TO_DO	DOING	DONE	2
3	act3	TO_DO	DOING	DONE	3
4	actividad1	TO_DO	DOING	DONE	1
5	actividad2	TO_DO	DOING	DONE	2
6	actividad3	TO_DO	DOING	DONE	3
\.


--
-- Name: sgpa_actividad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_actividad_id_seq', 6, true);


--
-- Data for Name: sgpa_cliente; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_cliente (id, nombre, direccion, telefono, observacion, correo, estado) FROM stdin;
1	NIKE	ddscdc	sdfdsfd	weewfe		ACT
2	PUMA	ddscdc	sdfdsfd	weewfe		ACT
\.


--
-- Name: sgpa_cliente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_cliente_id_seq', 2, true);


--
-- Data for Name: sgpa_equipo; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_equipo (id, hora, proyecto_id, rol_id, usuario_id) FROM stdin;
7	5	2	6	6
8	10	1	6	8
3	1	1	3	7
9	10	1	2	3
5	1	2	2	7
6	10	2	6	3
\.


--
-- Name: sgpa_equipo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_equipo_id_seq', 9, true);


--
-- Data for Name: sgpa_files; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_files (id, nombre, dato) FROM stdin;
1	/home/luis/cena.txt	\\x6c7569732067616c65616e6f0a
2	/home/luis/1.sh	\\x4e4956454c3d31350a6466202d6b207c2067726570205e2f646576207c2061776b20277b207072696e742024312c202435207d3b27207c207472202d6420222522207c0a7768696c6520726561642044455620504f52430a646f0a20206966205b2024504f5243202d677420244e4956454c205d0a20207468656e0a20202020206563686f2022244445562024504f5243203a20736f6272657061736120656c206e6976656c22203e3e202f746d702f63686b2e6c6f672e24240a202066690a646f6e650a0a6966205b202d66202f746d702f63686b2e6c6f672e2424205d0a7468656e0a2020206563686f2022656e7669617220636f7272656f220a202020636174202f746d702f63686b2e6c6f672e24240a202020726d202d66202f746d702f63686b2e6c6f672e24240a66690a0a
\.


--
-- Name: sgpa_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_files_id_seq', 2, true);


--
-- Data for Name: sgpa_flujo; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_flujo (id, nombre, descripcion, cantidad) FROM stdin;
1	flujo1	flujo	3
2	flujo2	flujo2	3
\.


--
-- Data for Name: sgpa_flujo_actividades; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_flujo_actividades (id, flujo_id, actividad_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	2	4
5	2	5
6	2	6
\.


--
-- Name: sgpa_flujo_actividades_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_flujo_actividades_id_seq', 6, true);


--
-- Name: sgpa_flujo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_flujo_id_seq', 2, true);


--
-- Data for Name: sgpa_historia; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_historia (id, nombre, usuario, fecha, descripcion, hu_id) FROM stdin;
8	Crear	admin	2015-06-19 15:04:15.130118	Se Crea el HU	4
9	Crear	admin	2015-06-19 15:04:57.060434	Se Crea el HU	5
10	Cambiar Estado	admin	2015-06-19 15:05:20.546947	Se cambio el estado a APR	4
11	Crear	admin	2015-06-19 16:19:22.724685	Se Crea el HU	6
12	Crear	admin	2015-06-19 16:19:37.534105	Se Crea el HU	7
13	Cambiar Estado	admin	2015-06-19 16:20:17.693146	Se cambio el estado a APR	6
14	Asignar Responsable	admin	2015-06-19 19:08:02.221588	Se Asigna un Responsable al HU	6
15	Asignar Responsable	admin	2015-06-19 19:43:44.304353	Se Asigna un Responsable al HU	6
16	Crear	admin	2015-06-19 20:46:09.524278	Se Crea el HU	8
17	Cambiar Estado	admin	2015-06-19 20:46:31.647953	Se cambio el estado a APR	7
18	Cambiar Estado	admin	2015-06-19 20:46:43.382243	Se cambio el estado a APR	8
19	Asignar Responsable	admin	2015-06-19 21:17:09.848778	Se Asigna un Responsable al HU	6
20	Crear	admin	2015-06-19 22:27:23.833197	Se Crea el HU	9
21	Cambiar Estado	admin	2015-06-19 22:27:40.423454	Se cambio el estado a APR	9
22	Asignar a Flujo	admin	2015-06-20 00:40:04.401889	El Hu se asigna a un flujo	6
23	Asignar a Flujo	admin	2015-06-20 00:44:27.103591	El Hu se asigna a un flujo	6
24	Asignar a Flujo	admin	2015-06-20 00:46:15.724601	El Hu se asigna a un flujo	6
25	Asignar a Flujo	admin	2015-06-20 00:46:51.261318	El Hu se asigna a un flujo	6
26	Asignar a Flujo	admin	2015-06-20 00:47:22.597619	El Hu se asigna a un flujo	6
27	Crear	admin	2015-06-20 04:27:18.231954	Se Crea el HU	10
28	Cambiar Estado	admin	2015-06-20 04:27:35.055642	Se cambio el estado a APR	10
29	Cambiar Estado	admin	2015-06-20 04:27:43.145226	Se cambio el estado a APR	5
30	Asignar Responsable	admin	2015-06-20 04:30:51.085220	Se Asigna un Responsable al HU	4
31	Asignar Responsable	admin	2015-06-20 04:31:14.898497	Se Asigna un Responsable al HU	5
32	Asignar Responsable	admin	2015-06-20 04:35:04.688701	Se Asigna un Responsable al HU	9
33	Asignar Responsable	admin	2015-06-20 04:35:59.503206	Se Asigna un Responsable al HU	8
34	Asignar Responsable	admin	2015-06-20 04:36:16.149109	Se Asigna un Responsable al HU	7
\.


--
-- Name: sgpa_historia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_historia_id_seq', 34, true);


--
-- Data for Name: sgpa_hu; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_hu (id, nombre, observacion, valornegocio, valortecnico, hora, estadorevision, estadodesarrolllo, estadoflujo, actividad_id, flujo_id, proyecto_id, responsable_id, horat) FROM stdin;
4	crear cliente	c	4	1	5	APR	PRO	TOD	1	1	2	3	0
5	eliminar cliente	e	3	1	4	APR	PRO	TOD	1	1	2	6	0
6	HU1	H	1	1	2	APR	PRO	DON	2	1	1	7	0
10	modificar cliente	modificar cliente	5	1	1	APR	PRO	TOD	1	1	2	3	0
9	hu5	h	1	1	1	APR	PRO	TOD	1	1	1	7	0
8	hu3	h	1	1	5	APR	PRO	TOD	4	2	1	8	0
7	HU2	H	4	1	7	APR	PRO	TOD	4	2	1	8	0
\.


--
-- Name: sgpa_hu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_hu_id_seq', 10, true);


--
-- Data for Name: sgpa_permiso; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_permiso (id, nombre, descripcion, tipo) FROM stdin;
1	crear rol sistema	creae rol sistema	SISTEMA
2	modificar rol sistema	creae rol sistema	SISTEMA
3	eliminar rol sistema	creae rol sistema	SISTEMA
4	crear usuario	creae rol sistema	SISTEMA
5	modificar usuario	creae rol sistema	SISTEMA
6	eliminar usuario	creae rol sistema	SISTEMA
7	crear cliente	creae rol sistema	SISTEMA
8	modificar cliente	creae rol sistema	SISTEMA
9	eliminar cliente	creae rol sistema	SISTEMA
10	crear proyecto	creae rol sistema	SISTEMA
11	modificar proyecto	creae rol sistema	SISTEMA
12	eliminar proyecto	creae rol sistema	SISTEMA
13	ver proyecto	creae rol sistema	SISTEMA
14	ver cliente	creae rol sistema	SISTEMA
15	ver usuario	creae rol sistema	SISTEMA
16	ver rol sistema	creae rol sistema	SISTEMA
17	modificar flujo	creae rol sistema	SISTEMA
18	eliminar flujo	creae rol sistema	SISTEMA
19	crear flujo	creae rol sistema	SISTEMA
20	ver flujo	creae rol sistema	SISTEMA
21	agregar actividad	creae rol sistema	SISTEMA
22	asignar equipo	creae rol sistema	PROYECTO
30	ver rol proyecto	creae rol sistema	SISTEMA
31	crear rol proyecto	creae rol sistema	SISTEMA
32	modificar rol proyecto	creae rol sistema	SISTEMA
33	eliminar rol proyecto	creae rol sistema	SISTEMA
34	cambiar estado cliente	creae rol sistema	SISTEMA
35	reasignar lider	creae rol sistema	SISTEMA
36	cambiar estado proyecto	creae rol sistema	SISTEMA
37	asignar cliente a usuario	creae rol sistema	SISTEMA
38	asignar rol sistema	creae rol sistema	SISTEMA
39	cambiar estado usuario	creae rol sistema	SISTEMA
40	activar sprint	creae rol sistema	PROYECTO
41	eliminar miembro	puede eliminar miembros del equipo de trabajo	PROYECTO
42	gestionar sprint	creae rol sistema	PROYECTO
43	ver equipo	puede ver los detalles de un equipo de trabajo	PROYECTO
44	agregar miembro	puede agregar miembrios a un equipo de trabajo	PROYECTO
45	crear sprint	puede crear un sprint	PROYECTO
46	ver sprint	puede ver detalles de un sprint	PROYECTO
47	agregar flujo	puede agregar flujos de trabajo	PROYECTO
48	ver kanban	puede acceder al tablero kanban	PROYECTO
49	ver burndownchart	puede ver el burndown chart 	PROYECTO
52	crear historia de usuario	puede crear historias de usuarios	PROYECTO
54	ver historia de usuario	puede ver detalles de historias de usuarios	PROYECTO
55	modificar historia de usuario	puede modificar datos de historias de usuarios	PROYECTO
56	eliminar historia de usuario	puede eliminar historias de usuarios	PROYECTO
59	cambiar estado de historia de usuario	puede cambiar estados de historias de usuarios	PROYECTO
60	ver historial de historia de usuario	puede ver el historial de  una historia de usuario	PROYECTO
61	asignar responsable a historia de usuario	puede asignar un responsable a una HU	PROYECTO
62	agregar historia de usuario a sprint	puede agregar hu a un sprint	PROYECTO
63	editar hu de sprint backlog	puede editar las hu de un sprint backlog	PROYECTO
67	finalizar sprint	puede finalizar un sprint	PROYECTO
68	ver release	puede ver la lista de release de sprints	PROYECTO
69	ver trabajo	puede ver el trabajo	PROYECTO
70	descargar archivo	puede descargar un archivo	PROYECTO
71	agregar trabajo	puede agregar un trabajo	PROYECTO
72	avanzar historia de usuario	puede avanzar una HU	PROYECTO
73	cambiar flujo de historia de usuario	puede cambiar de flujo una HU	PROYECTO
74	retroceder historia de usuario	puede retroceder una HU	PROYECTO
75	finalizar historia de usuario	puede finalizar una HU	PROYECTO
\.


--
-- Name: sgpa_permiso_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_permiso_id_seq', 75, true);


--
-- Data for Name: sgpa_proyecto; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_proyecto (id, "fechaInicio", "fechaFin", "fechaMod", nombre, estado, cliente_id, lider_id) FROM stdin;
1	2015-05-04	2015-07-22	2015-06-05	Proyecto1	ACTIVO	1	1
2	2015-06-02	2015-06-25	2015-06-10	Proyecto2	ACTIVO	1	1
3	2015-02-01	2015-07-10		Proyecto3	PENDIENTE	2	3
\.


--
-- Data for Name: sgpa_proyecto_flujo; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_proyecto_flujo (id, proyecto_id, flujo_id) FROM stdin;
7	1	1
8	1	2
9	2	1
10	2	2
\.


--
-- Name: sgpa_proyecto_flujo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_proyecto_flujo_id_seq', 10, true);


--
-- Name: sgpa_proyecto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_proyecto_id_seq', 3, true);


--
-- Data for Name: sgpa_rol; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_rol (id, nombre, descripcion, tipo) FROM stdin;
1	Administrador	administrador	SISTEMA
2	Scrum Master	Scrum Master	PROYECTO
6	Gestor de Equipo	Gestor de Equipoprueba	PROYECTO
3	Desarrollador	Desarrollador	PROYECTO
4	Administrar Clientes	Administrar Clientes	SISTEMA
5	Administrar Roles	Administrar Roles	SISTEMA
\.


--
-- Name: sgpa_rol_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_rol_id_seq', 6, true);


--
-- Data for Name: sgpa_rol_permisos; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_rol_permisos (id, rol_id, permiso_id) FROM stdin;
1	1	1
2	1	2
3	1	3
4	1	4
5	1	5
6	1	6
7	1	7
8	1	8
9	1	9
10	1	10
11	1	11
12	1	12
13	1	13
14	1	14
15	1	15
16	1	16
17	1	17
18	1	18
19	1	19
20	1	20
21	1	21
22	1	22
536	3	68
537	3	54
538	3	70
539	3	71
540	3	72
541	3	73
542	3	74
30	1	30
31	1	31
32	1	32
33	1	33
34	1	34
35	1	35
36	1	36
37	1	37
38	1	38
39	1	39
40	1	40
41	1	41
42	1	42
43	1	43
543	3	46
544	3	48
545	3	49
546	3	22
547	3	60
548	3	69
556	4	8
557	4	9
558	4	14
559	4	7
560	5	32
561	5	1
381	1	44
562	5	2
563	5	3
564	5	33
565	5	21
386	1	45
387	1	46
388	1	47
389	1	48
566	5	30
567	5	31
459	1	62
397	1	49
398	1	52
399	1	54
400	1	55
401	1	56
402	1	59
403	1	60
404	1	61
472	1	63
486	1	67
487	1	68
488	1	69
489	1	70
490	1	71
492	1	73
493	1	72
494	1	74
495	1	75
496	2	22
497	2	40
498	2	41
499	2	42
500	2	43
501	2	44
502	2	45
503	2	46
504	2	47
505	2	48
506	2	49
507	2	52
508	2	54
509	2	55
510	2	56
511	2	59
512	2	60
513	2	61
514	2	62
515	2	63
516	2	67
517	2	68
518	2	69
519	2	70
520	2	71
521	2	72
522	2	73
523	2	74
524	2	75
525	6	68
526	6	22
527	6	70
528	6	41
529	6	43
530	6	44
531	6	46
532	6	48
533	6	49
534	6	54
535	6	69
\.


--
-- Name: sgpa_rol_permisos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_rol_permisos_id_seq', 567, true);


--
-- Data for Name: sgpa_sprint; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_sprint (id, duracion, "fechaInicio", "fechaFin", nombre, estado, proyecto_id) FROM stdin;
2	10	2015-05-21	2015-05-31	Sprint_2	INA	1
1	17	2015-05-04	2015-05-21	Sprint_1	INA	1
5	7	2015-06-03	2015-06-10	Sprint_1	INA	2
3	2	2015-06-01	2015-06-03	Sprint_3	INA	1
4	2	2015-06-03	2015-06-05	Sprint_4	INA	1
\.


--
-- Data for Name: sgpa_sprint_hu; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_sprint_hu (id, sprint_id, hu_id) FROM stdin;
3	1	6
4	1	7
5	1	8
6	1	9
7	5	4
8	5	10
9	5	5
\.


--
-- Name: sgpa_sprint_hu_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_sprint_hu_id_seq', 9, true);


--
-- Name: sgpa_sprint_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_sprint_id_seq', 5, true);


--
-- Data for Name: sgpa_trabajo; Type: TABLE DATA; Schema: public; Owner: roberto
--

COPY sgpa_trabajo (id, nombre, horas, fecha, nota, actor, filename, size, flujo, actividad, estado, sprint, archivo_id, hu_id) FROM stdin;
9	Avanzar	0	2015-06-19	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
10	Retroceder	0	2015-06-19	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
11	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
12	Retroceder	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
13	Cambiar Flujo	0	2015-06-20	Cambio de Flujo del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
14	Cambiar Flujo	0	2015-06-20	Cambio de Flujo del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
15	Cambiar Flujo	0	2015-06-20	Cambio de Flujo del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
16	Cambiar Flujo	0	2015-06-20	Cambio de Flujo del HU	prueba1	\N	\N	flujo2	actividad1	TOD	\N	\N	6
17	Cambiar Flujo	0	2015-06-20	Cambio de Flujo del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
18	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
19	Retroceder	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
20	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
21	Retroceder	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
22	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	TOD	\N	\N	6
23	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
24	Retroceder	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DON	\N	\N	6
25	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DOI	\N	\N	6
26	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act1	DON	\N	\N	6
27	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act2	TOD	\N	\N	6
28	Avanzar	0	2015-06-20	Cambio de Estado del HU	prueba1	\N	\N	flujo1	act2	DOI	\N	\N	6
\.


--
-- Name: sgpa_trabajo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: roberto
--

SELECT pg_catalog.setval('sgpa_trabajo_id_seq', 28, true);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_cf901bb0fdd2ad0_uniq; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_cf901bb0fdd2ad0_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT auth_user_roles_pkey PRIMARY KEY (id);


--
-- Name: auth_user_roles_user_id_rol_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT auth_user_roles_user_id_rol_id_key UNIQUE (user_id, rol_id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_45f3b1d93ec8c61c_uniq; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_45f3b1d93ec8c61c_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: sgpa_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_actividad
    ADD CONSTRAINT sgpa_actividad_pkey PRIMARY KEY (id);


--
-- Name: sgpa_cliente_nombre_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_cliente
    ADD CONSTRAINT sgpa_cliente_nombre_key UNIQUE (nombre);


--
-- Name: sgpa_cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_cliente
    ADD CONSTRAINT sgpa_cliente_pkey PRIMARY KEY (id);


--
-- Name: sgpa_equipo_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_pkey PRIMARY KEY (id);


--
-- Name: sgpa_files_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_files
    ADD CONSTRAINT sgpa_files_pkey PRIMARY KEY (id);


--
-- Name: sgpa_flujo_actividades_flujo_id_actividad_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT sgpa_flujo_actividades_flujo_id_actividad_id_key UNIQUE (flujo_id, actividad_id);


--
-- Name: sgpa_flujo_actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT sgpa_flujo_actividades_pkey PRIMARY KEY (id);


--
-- Name: sgpa_flujo_descripcion_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_flujo
    ADD CONSTRAINT sgpa_flujo_descripcion_key UNIQUE (descripcion);


--
-- Name: sgpa_flujo_nombre_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_flujo
    ADD CONSTRAINT sgpa_flujo_nombre_key UNIQUE (nombre);


--
-- Name: sgpa_flujo_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_flujo
    ADD CONSTRAINT sgpa_flujo_pkey PRIMARY KEY (id);


--
-- Name: sgpa_historia_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_historia
    ADD CONSTRAINT sgpa_historia_pkey PRIMARY KEY (id);


--
-- Name: sgpa_hu_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_pkey PRIMARY KEY (id);


--
-- Name: sgpa_permiso_nombre_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_permiso
    ADD CONSTRAINT sgpa_permiso_nombre_key UNIQUE (nombre);


--
-- Name: sgpa_permiso_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_permiso
    ADD CONSTRAINT sgpa_permiso_pkey PRIMARY KEY (id);


--
-- Name: sgpa_proyecto_flujo_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT sgpa_proyecto_flujo_pkey PRIMARY KEY (id);


--
-- Name: sgpa_proyecto_flujo_proyecto_id_flujo_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT sgpa_proyecto_flujo_proyecto_id_flujo_id_key UNIQUE (proyecto_id, flujo_id);


--
-- Name: sgpa_proyecto_nombre_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_nombre_key UNIQUE (nombre);


--
-- Name: sgpa_proyecto_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_pkey PRIMARY KEY (id);


--
-- Name: sgpa_rol_nombre_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_rol
    ADD CONSTRAINT sgpa_rol_nombre_key UNIQUE (nombre);


--
-- Name: sgpa_rol_permisos_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT sgpa_rol_permisos_pkey PRIMARY KEY (id);


--
-- Name: sgpa_rol_permisos_rol_id_permiso_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT sgpa_rol_permisos_rol_id_permiso_id_key UNIQUE (rol_id, permiso_id);


--
-- Name: sgpa_rol_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_rol
    ADD CONSTRAINT sgpa_rol_pkey PRIMARY KEY (id);


--
-- Name: sgpa_sprint_hu_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sgpa_sprint_hu_pkey PRIMARY KEY (id);


--
-- Name: sgpa_sprint_hu_sprint_id_hu_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sgpa_sprint_hu_sprint_id_hu_id_key UNIQUE (sprint_id, hu_id);


--
-- Name: sgpa_sprint_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_sprint
    ADD CONSTRAINT sgpa_sprint_pkey PRIMARY KEY (id);


--
-- Name: sgpa_trabajo_archivo_id_key; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_archivo_id_key UNIQUE (archivo_id);


--
-- Name: sgpa_trabajo_pkey; Type: CONSTRAINT; Schema: public; Owner: roberto; Tablespace: 
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_253ae2a6331666e8_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_name_253ae2a6331666e8_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_name_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_name_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_4a860110; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_4a860110 ON auth_user USING btree (cliente_id);


--
-- Name: auth_user_cliente_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_cliente_id ON auth_user USING btree (cliente_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_roles_592e25ad; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_roles_592e25ad ON auth_user_roles USING btree (rol_id);


--
-- Name: auth_user_roles_e8701ad4; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_roles_e8701ad4 ON auth_user_roles USING btree (user_id);


--
-- Name: auth_user_roles_rol_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_roles_rol_id ON auth_user_roles USING btree (rol_id);


--
-- Name: auth_user_roles_user_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_roles_user_id ON auth_user_roles USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_51b3b110094b8aae_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_username_51b3b110094b8aae_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: auth_user_username_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX auth_user_username_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_461cfeaa630ca218_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_session_session_key_461cfeaa630ca218_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_session_session_key_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX django_session_session_key_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: sgpa_cliente_nombre_353fe84d3461efec_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_cliente_nombre_353fe84d3461efec_like ON sgpa_cliente USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_cliente_nombre_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_cliente_nombre_like ON sgpa_cliente USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_equipo_592e25ad; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_592e25ad ON sgpa_equipo USING btree (rol_id);


--
-- Name: sgpa_equipo_abfe0f96; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_abfe0f96 ON sgpa_equipo USING btree (usuario_id);


--
-- Name: sgpa_equipo_f543c3f9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_f543c3f9 ON sgpa_equipo USING btree (proyecto_id);


--
-- Name: sgpa_equipo_proyecto_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_proyecto_id ON sgpa_equipo USING btree (proyecto_id);


--
-- Name: sgpa_equipo_rol_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_rol_id ON sgpa_equipo USING btree (rol_id);


--
-- Name: sgpa_equipo_usuario_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_equipo_usuario_id ON sgpa_equipo USING btree (usuario_id);


--
-- Name: sgpa_flujo_actividades_6f919ae9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_actividades_6f919ae9 ON sgpa_flujo_actividades USING btree (actividad_id);


--
-- Name: sgpa_flujo_actividades_actividad_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_actividades_actividad_id ON sgpa_flujo_actividades USING btree (actividad_id);


--
-- Name: sgpa_flujo_actividades_bd1d5624; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_actividades_bd1d5624 ON sgpa_flujo_actividades USING btree (flujo_id);


--
-- Name: sgpa_flujo_actividades_flujo_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_actividades_flujo_id ON sgpa_flujo_actividades USING btree (flujo_id);


--
-- Name: sgpa_flujo_descripcion_9a953c28fa77f0d_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_descripcion_9a953c28fa77f0d_like ON sgpa_flujo USING btree (descripcion varchar_pattern_ops);


--
-- Name: sgpa_flujo_descripcion_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_descripcion_like ON sgpa_flujo USING btree (descripcion varchar_pattern_ops);


--
-- Name: sgpa_flujo_nombre_232a1815af1a7df6_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_nombre_232a1815af1a7df6_like ON sgpa_flujo USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_flujo_nombre_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_flujo_nombre_like ON sgpa_flujo USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_historia_4ffab8af; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_historia_4ffab8af ON sgpa_historia USING btree (hu_id);


--
-- Name: sgpa_historia_hu_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_historia_hu_id ON sgpa_historia USING btree (hu_id);


--
-- Name: sgpa_hu_1ba06e10; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_1ba06e10 ON sgpa_hu USING btree (responsable_id);


--
-- Name: sgpa_hu_6f919ae9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_6f919ae9 ON sgpa_hu USING btree (actividad_id);


--
-- Name: sgpa_hu_actividad_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_actividad_id ON sgpa_hu USING btree (actividad_id);


--
-- Name: sgpa_hu_bd1d5624; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_bd1d5624 ON sgpa_hu USING btree (flujo_id);


--
-- Name: sgpa_hu_f543c3f9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_f543c3f9 ON sgpa_hu USING btree (proyecto_id);


--
-- Name: sgpa_hu_flujo_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_flujo_id ON sgpa_hu USING btree (flujo_id);


--
-- Name: sgpa_hu_proyecto_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_proyecto_id ON sgpa_hu USING btree (proyecto_id);


--
-- Name: sgpa_hu_responsable_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_hu_responsable_id ON sgpa_hu USING btree (responsable_id);


--
-- Name: sgpa_permiso_nombre_51c53117d9ce2f4d_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_permiso_nombre_51c53117d9ce2f4d_like ON sgpa_permiso USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_permiso_nombre_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_permiso_nombre_like ON sgpa_permiso USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_proyecto_13e8b487; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_13e8b487 ON sgpa_proyecto USING btree (lider_id);


--
-- Name: sgpa_proyecto_4a860110; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_4a860110 ON sgpa_proyecto USING btree (cliente_id);


--
-- Name: sgpa_proyecto_cliente_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_cliente_id ON sgpa_proyecto USING btree (cliente_id);


--
-- Name: sgpa_proyecto_flujo_bd1d5624; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_flujo_bd1d5624 ON sgpa_proyecto_flujo USING btree (flujo_id);


--
-- Name: sgpa_proyecto_flujo_f543c3f9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_flujo_f543c3f9 ON sgpa_proyecto_flujo USING btree (proyecto_id);


--
-- Name: sgpa_proyecto_flujo_flujo_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_flujo_flujo_id ON sgpa_proyecto_flujo USING btree (flujo_id);


--
-- Name: sgpa_proyecto_flujo_proyecto_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_flujo_proyecto_id ON sgpa_proyecto_flujo USING btree (proyecto_id);


--
-- Name: sgpa_proyecto_lider_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_lider_id ON sgpa_proyecto USING btree (lider_id);


--
-- Name: sgpa_proyecto_nombre_6589e927f91dfec2_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_nombre_6589e927f91dfec2_like ON sgpa_proyecto USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_proyecto_nombre_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_proyecto_nombre_like ON sgpa_proyecto USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_rol_nombre_1e82bed120136a39_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_nombre_1e82bed120136a39_like ON sgpa_rol USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_rol_nombre_like; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_nombre_like ON sgpa_rol USING btree (nombre varchar_pattern_ops);


--
-- Name: sgpa_rol_permisos_592e25ad; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_permisos_592e25ad ON sgpa_rol_permisos USING btree (rol_id);


--
-- Name: sgpa_rol_permisos_5dafd25e; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_permisos_5dafd25e ON sgpa_rol_permisos USING btree (permiso_id);


--
-- Name: sgpa_rol_permisos_permiso_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_permisos_permiso_id ON sgpa_rol_permisos USING btree (permiso_id);


--
-- Name: sgpa_rol_permisos_rol_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_rol_permisos_rol_id ON sgpa_rol_permisos USING btree (rol_id);


--
-- Name: sgpa_sprint_f543c3f9; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_f543c3f9 ON sgpa_sprint USING btree (proyecto_id);


--
-- Name: sgpa_sprint_hu_4ffab8af; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_hu_4ffab8af ON sgpa_sprint_hu USING btree (hu_id);


--
-- Name: sgpa_sprint_hu_b688f27b; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_hu_b688f27b ON sgpa_sprint_hu USING btree (sprint_id);


--
-- Name: sgpa_sprint_hu_hu_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_hu_hu_id ON sgpa_sprint_hu USING btree (hu_id);


--
-- Name: sgpa_sprint_hu_sprint_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_hu_sprint_id ON sgpa_sprint_hu USING btree (sprint_id);


--
-- Name: sgpa_sprint_proyecto_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_sprint_proyecto_id ON sgpa_sprint USING btree (proyecto_id);


--
-- Name: sgpa_trabajo_4ffab8af; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_trabajo_4ffab8af ON sgpa_trabajo USING btree (hu_id);


--
-- Name: sgpa_trabajo_hu_id; Type: INDEX; Schema: public; Owner: roberto; Tablespace: 
--

CREATE INDEX sgpa_trabajo_hu_id ON sgpa_trabajo USING btree (hu_id);


--
-- Name: auth_content_type_id_508cf46651277a81_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_content_type_id_508cf46651277a81_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_group_id_689710a9a73b7457_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user__permission_id_384b62483d7071f0_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_cliente_id_1dbde9df304c76ae_fk_sgpa_cliente_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_cliente_id_1dbde9df304c76ae_fk_sgpa_cliente_id FOREIGN KEY (cliente_id) REFERENCES sgpa_cliente(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_roles_rol_id_390d4222eb15e143_fk_sgpa_rol_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT auth_user_roles_rol_id_390d4222eb15e143_fk_sgpa_rol_id FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_roles_user_id_271fe386eea96ec6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT auth_user_roles_user_id_271fe386eea96ec6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT auth_user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permiss_user_id_7f0938558328534a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cliente_id_refs_id_14320341; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT cliente_id_refs_id_14320341 FOREIGN KEY (cliente_id) REFERENCES sgpa_cliente(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_d043b34a; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_d043b34a FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: djan_content_type_id_697914295151027a_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT djan_content_type_id_697914295151027a_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: flujo_id_refs_id_4dac18f7; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT flujo_id_refs_id_4dac18f7 FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_f4b32aac; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_f4b32aac FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proyecto_id_refs_id_682a0594; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT proyecto_id_refs_id_682a0594 FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rol_id_refs_id_16f177eb; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT rol_id_refs_id_16f177eb FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rol_id_refs_id_6d9ae20d; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_roles
    ADD CONSTRAINT rol_id_refs_id_6d9ae20d FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_proyecto_id_773f88d453dfea6f_fk_sgpa_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_proyecto_id_773f88d453dfea6f_fk_sgpa_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_proyecto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_proyecto_id_fkey FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_rol_id_325e9594dd7118a8_fk_sgpa_rol_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_rol_id_325e9594dd7118a8_fk_sgpa_rol_id FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_rol_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_rol_id_fkey FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_usuario_id_7b1760201901da41_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_usuario_id_7b1760201901da41_fk_auth_user_id FOREIGN KEY (usuario_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_equipo_usuario_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_equipo
    ADD CONSTRAINT sgpa_equipo_usuario_id_fkey FOREIGN KEY (usuario_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_flujo_a_actividad_id_3e20752ed569517c_fk_sgpa_actividad_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT sgpa_flujo_a_actividad_id_3e20752ed569517c_fk_sgpa_actividad_id FOREIGN KEY (actividad_id) REFERENCES sgpa_actividad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_flujo_actividad_flujo_id_4c944af3fefb3785_fk_sgpa_flujo_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT sgpa_flujo_actividad_flujo_id_4c944af3fefb3785_fk_sgpa_flujo_id FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_flujo_actividades_actividad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_flujo_actividades
    ADD CONSTRAINT sgpa_flujo_actividades_actividad_id_fkey FOREIGN KEY (actividad_id) REFERENCES sgpa_actividad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_historia_hu_id_27f512279caafcf7_fk_sgpa_hu_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_historia
    ADD CONSTRAINT sgpa_historia_hu_id_27f512279caafcf7_fk_sgpa_hu_id FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_historia_hu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_historia
    ADD CONSTRAINT sgpa_historia_hu_id_fkey FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_actividad_id_7800dd2dd6d2dc42_fk_sgpa_actividad_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_actividad_id_7800dd2dd6d2dc42_fk_sgpa_actividad_id FOREIGN KEY (actividad_id) REFERENCES sgpa_actividad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_actividad_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_actividad_id_fkey FOREIGN KEY (actividad_id) REFERENCES sgpa_actividad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_flujo_id_2b2d6f17c4ec25b5_fk_sgpa_flujo_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_flujo_id_2b2d6f17c4ec25b5_fk_sgpa_flujo_id FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_flujo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_flujo_id_fkey FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_proyecto_id_3ade5ddc24261703_fk_sgpa_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_proyecto_id_3ade5ddc24261703_fk_sgpa_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_proyecto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_proyecto_id_fkey FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_responsable_id_2ba2588741567dcf_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_responsable_id_2ba2588741567dcf_fk_auth_user_id FOREIGN KEY (responsable_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_hu_responsable_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_hu
    ADD CONSTRAINT sgpa_hu_responsable_id_fkey FOREIGN KEY (responsable_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto__proyecto_id_7fbfc516950b15a8_fk_sgpa_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT sgpa_proyecto__proyecto_id_7fbfc516950b15a8_fk_sgpa_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_cliente_id_2630e0a011185a3_fk_sgpa_cliente_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_cliente_id_2630e0a011185a3_fk_sgpa_cliente_id FOREIGN KEY (cliente_id) REFERENCES sgpa_cliente(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_cliente_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_cliente_id_fkey FOREIGN KEY (cliente_id) REFERENCES sgpa_cliente(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_flujo_flujo_id_31c554a31dc0aa1a_fk_sgpa_flujo_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT sgpa_proyecto_flujo_flujo_id_31c554a31dc0aa1a_fk_sgpa_flujo_id FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_flujo_flujo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto_flujo
    ADD CONSTRAINT sgpa_proyecto_flujo_flujo_id_fkey FOREIGN KEY (flujo_id) REFERENCES sgpa_flujo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_lider_id_4433c9641fce2fa7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_lider_id_4433c9641fce2fa7_fk_auth_user_id FOREIGN KEY (lider_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_proyecto_lider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_proyecto
    ADD CONSTRAINT sgpa_proyecto_lider_id_fkey FOREIGN KEY (lider_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_rol_permiso_permiso_id_5963a42372501b0d_fk_sgpa_permiso_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT sgpa_rol_permiso_permiso_id_5963a42372501b0d_fk_sgpa_permiso_id FOREIGN KEY (permiso_id) REFERENCES sgpa_permiso(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_rol_permisos_permiso_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT sgpa_rol_permisos_permiso_id_fkey FOREIGN KEY (permiso_id) REFERENCES sgpa_permiso(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_rol_permisos_rol_id_54306acb7e237e35_fk_sgpa_rol_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_rol_permisos
    ADD CONSTRAINT sgpa_rol_permisos_rol_id_54306acb7e237e35_fk_sgpa_rol_id FOREIGN KEY (rol_id) REFERENCES sgpa_rol(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_sprint_hu_hu_id_3b71f77f89825f87_fk_sgpa_hu_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sgpa_sprint_hu_hu_id_3b71f77f89825f87_fk_sgpa_hu_id FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_sprint_hu_hu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sgpa_sprint_hu_hu_id_fkey FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_sprint_hu_sprint_id_4fd11fc936aa5626_fk_sgpa_sprint_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sgpa_sprint_hu_sprint_id_4fd11fc936aa5626_fk_sgpa_sprint_id FOREIGN KEY (sprint_id) REFERENCES sgpa_sprint(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_sprint_proyecto_id_689464e55e8afb56_fk_sgpa_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint
    ADD CONSTRAINT sgpa_sprint_proyecto_id_689464e55e8afb56_fk_sgpa_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_sprint_proyecto_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint
    ADD CONSTRAINT sgpa_sprint_proyecto_id_fkey FOREIGN KEY (proyecto_id) REFERENCES sgpa_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_trabajo_archivo_id_176a07a312d2a122_fk_sgpa_files_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_archivo_id_176a07a312d2a122_fk_sgpa_files_id FOREIGN KEY (archivo_id) REFERENCES sgpa_files(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_trabajo_archivo_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_archivo_id_fkey FOREIGN KEY (archivo_id) REFERENCES sgpa_files(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_trabajo_hu_id_2357352373cfdf7e_fk_sgpa_hu_id; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_hu_id_2357352373cfdf7e_fk_sgpa_hu_id FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sgpa_trabajo_hu_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_trabajo
    ADD CONSTRAINT sgpa_trabajo_hu_id_fkey FOREIGN KEY (hu_id) REFERENCES sgpa_hu(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: sprint_id_refs_id_15144908; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY sgpa_sprint_hu
    ADD CONSTRAINT sprint_id_refs_id_15144908 FOREIGN KEY (sprint_id) REFERENCES sgpa_sprint(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_40c41112; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_40c41112 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_4dc23c39; Type: FK CONSTRAINT; Schema: public; Owner: roberto
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_4dc23c39 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

