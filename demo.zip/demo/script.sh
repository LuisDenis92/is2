#!/bin/bash

# -*- ENCODING: UTF-8 -*-
# para hacer backup:  pg_dump demo > backup.sql
OPCIONES="Produccion Desarrollo Salir"
 
echo "Seleccione la opcion que desea:"
select opt in $OPCIONES; do
  if [ "$opt" = "Desarrollo" ]; then
	dropdb --if-exists demo
	createdb demo 
 	psql -f backup.sql -U luis demo
	exit
  elif [ "$opt" = "Produccion" ]; then
	dropdb --if-exists produccion
	createdb produccion 
 	psql -f backup.sql -U luis produccion
	exit
  elif [ "$opt" = "Salir" ]; then
	exit
  else
	echo Opcion incorrecta
  fi
done


