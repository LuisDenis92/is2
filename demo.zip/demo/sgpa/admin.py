from django.contrib import admin
from sgpa.models import Proyecto, Permiso, Rol

admin.site.register(Proyecto)
