# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Actividad',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
                ('estado_1', models.CharField(default=b'TO_DO', max_length=5)),
                ('estado_2', models.CharField(default=b'DOING', max_length=5)),
                ('estado_3', models.CharField(default=b'DONE', max_length=5)),
                ('orden', models.IntegerField(default=0)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Cliente',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=32)),
                ('direccion', models.CharField(max_length=70)),
                ('telefono', models.CharField(max_length=70)),
                ('observacion', models.TextField(max_length=200)),
                ('correo', models.CharField(max_length=70)),
                ('estado', models.CharField(default=b'ACT', max_length=20, choices=[(b'ACTIVO', b'Activo'), (b'INACTIVO', b'Inactivo')])),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Equipo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('hora', models.IntegerField(default=1)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Files',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
                ('dato', models.BinaryField()),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Flujo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=60)),
                ('descripcion', models.CharField(unique=True, max_length=200)),
                ('cantidad', models.IntegerField(default=0)),
                ('actividades', models.ManyToManyField(related_name='actividades', to='sgpa.Actividad')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Historia',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
                ('usuario', models.CharField(max_length=60)),
                ('fecha', models.CharField(max_length=50)),
                ('descripcion', models.CharField(max_length=200)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Hu',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=32)),
                ('observacion', models.TextField(max_length=200)),
                ('valornegocio', models.IntegerField(default=1)),
                ('valortecnico', models.IntegerField(default=1)),
                ('hora', models.PositiveIntegerField(default=1)),
                ('estadorevision', models.CharField(default=b'PEN', max_length=20, choices=[(b'PEN', b'Pendiante'), (b'APR', b'Aprobado'), (b'REC', b'Rechazado')])),
                ('estadodesarrolllo', models.CharField(default=b'PRO', max_length=20, choices=[(b'SUS', b'Suspender'), (b'CAN', b'Cancelar'), (b'FIN', b'Finalizar'), (b'PRO', b'Procesar')])),
                ('estadoflujo', models.CharField(default=b'TOD', max_length=20, choices=[(b'TOD', b'To Do'), (b'DOI', b'Doing'), (b'DON', b'Done')])),
                ('actividad', models.ForeignKey(to='sgpa.Actividad', null=True)),
                ('flujo', models.ForeignKey(related_name='flujo', to='sgpa.Flujo', null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Permiso',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=60)),
                ('descripcion', models.CharField(max_length=120)),
                ('tipo', models.CharField(default=b'SISTEMA', max_length=8, choices=[(b'SISTEMA', b'Sistema'), (b'PROYECTO', b'Proyecto')])),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Proyecto',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('fechaInicio', models.CharField(max_length=20)),
                ('fechaFin', models.CharField(max_length=20)),
                ('fechaMod', models.CharField(max_length=20)),
                ('nombre', models.CharField(unique=True, max_length=32)),
                ('estado', models.CharField(default=b'PENDIENTE', max_length=20, choices=[(b'PENDIENTE', b'Pendiente'), (b'ANULADO', b'Anulado'), (b'ACTIVO', b'Activo'), (b'FINALIZADO', b'Finalizado')])),
                ('cliente', models.ForeignKey(default=b'', to='sgpa.Cliente')),
                ('flujo', models.ManyToManyField(related_name='flujopro', to='sgpa.Flujo')),
                ('lider', models.ForeignKey(related_name='lider', to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Rol',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(unique=True, max_length=60)),
                ('descripcion', models.CharField(max_length=120)),
                ('tipo', models.CharField(max_length=8, choices=[(b'SISTEMA', b'Sistema'), (b'PROYECTO', b'Proyecto')])),
                ('permisos', models.ManyToManyField(to='sgpa.Permiso')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Sprint',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('duracion', models.IntegerField(default=1)),
                ('fechaInicio', models.CharField(max_length=50)),
                ('fechaFin', models.CharField(max_length=50)),
                ('nombre', models.CharField(max_length=60)),
                ('estado', models.CharField(default=b'INA', max_length=20, choices=[(b'ACT', b'Activo'), (b'INA', b'Inactivo')])),
                ('hu', models.ManyToManyField(related_name='hu', to='sgpa.Hu')),
                ('proyecto', models.ForeignKey(related_name='project', to='sgpa.Proyecto', null=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Trabajo',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('nombre', models.CharField(max_length=60)),
                ('horas', models.PositiveIntegerField(default=0)),
                ('fecha', models.CharField(max_length=60)),
                ('nota', models.TextField(max_length=200)),
                ('actor', models.CharField(max_length=60)),
                ('filename', models.CharField(max_length=60, null=True)),
                ('size', models.IntegerField(null=True)),
                ('flujo', models.CharField(max_length=60, null=True)),
                ('actividad', models.CharField(max_length=60, null=True)),
                ('estado', models.CharField(max_length=60, null=True)),
                ('sprint', models.CharField(max_length=60, null=True)),
                ('archivo', models.OneToOneField(related_name='archivo', null=True, to='sgpa.Files')),
                ('hu', models.ForeignKey(related_name='historiatrabajo', to='sgpa.Hu')),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='hu',
            name='proyecto',
            field=models.ForeignKey(related_name='proyecto', to='sgpa.Proyecto', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='hu',
            name='responsable',
            field=models.ForeignKey(related_name='responsable', to=settings.AUTH_USER_MODEL, null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='historia',
            name='hu',
            field=models.ForeignKey(related_name='hishu', to='sgpa.Hu'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='equipo',
            name='proyecto',
            field=models.ForeignKey(related_name='proyectoequipo', to='sgpa.Proyecto', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='equipo',
            name='rol',
            field=models.ForeignKey(related_name='rolequipo', to='sgpa.Rol', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='equipo',
            name='usuario',
            field=models.ForeignKey(related_name='usuarioequipo', to=settings.AUTH_USER_MODEL),
            preserve_default=True,
        ),
    ]
