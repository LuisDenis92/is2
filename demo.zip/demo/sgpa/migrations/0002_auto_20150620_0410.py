# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('sgpa', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='hu',
            name='horat',
            field=models.PositiveIntegerField(default=1),
            preserve_default=True,
        ),
        migrations.AlterField(
            model_name='sprint',
            name='estado',
            field=models.CharField(default=b'INA', max_length=20, choices=[(b'ACT', b'Activo'), (b'FIN', b'Finalizado'), (b'INA', b'Inactivo')]),
            preserve_default=True,
        ),
    ]
