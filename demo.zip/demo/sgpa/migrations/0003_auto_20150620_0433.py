# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('sgpa', '0002_auto_20150620_0410'),
    ]

    operations = [
        migrations.AlterField(
            model_name='hu',
            name='horat',
            field=models.PositiveIntegerField(default=0),
            preserve_default=True,
        ),
    ]
