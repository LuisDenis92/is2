__author__ = 'luis'
from django.test import TestCase
from sgpa.models import Hu, Proyecto
from sgpa.views import avanzar



class SGPATestCase(TestCase):
	def test_avanzar_hu(self):

         print('\n------Ejecutando test para avanzar hu...-------')
         hu = Hu(nombre = 'hu', observacion= 'se crea un hu', estadoflujo='TOD')
         hu.estadoflujo='DOI'
         hu.save()
         self.assertEqual(hu.estadoflujo,'DOI')
