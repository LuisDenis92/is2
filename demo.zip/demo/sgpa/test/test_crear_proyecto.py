__author__ = 'luis'
from django.test import TestCase
from sgpa.models import Proyecto, Cliente



class SGPATestCase(TestCase):
	def test_crear_proyecto(self):

         print('\n------Ejecutando test para crear proyecto...-------')
         c = Cliente(nombre= 'cliente', correo='asd@ejemplo.com')
         c.save()
         p = Proyecto(fechaInicio= '12-05-2015', fechaFin='20-06-2015',nombre = 'proyecto', cliente= c)
         p.save()
         self.assertTrue(Proyecto.objects.exists())
