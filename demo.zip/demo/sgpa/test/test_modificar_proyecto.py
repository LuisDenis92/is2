__author__ = 'luis'
from django.test import TestCase
from sgpa.models import Proyecto, Cliente



class SGPATestCase(TestCase):
	def test_modificar_proyecto(self):

         print('\n------Ejecutando test para modificar proyecto...-------')
         c = Cliente(nombre= 'cliente', correo='asd@ejemplo.com')
         c.save()
         p1 = Proyecto(fechaInicio= '12-05-2015', fechaFin='20-06-2015',nombre = 'proyecto1', cliente= c)
         p2 = Proyecto(fechaInicio= '12-05-2015', fechaFin='20-06-2015',nombre = 'proyecto2', cliente= c)
         p2.fechaInicio = '13-06-2015'
         p2.save()
         self.assertNotEqual(p1.fechaInicio, p2.fechaInicio)
