from django.contrib.auth.models import User
from sgpa.models import Rol, Equipo

__author__ = 'roberto'

def obtenerPermisos(request):
    usuario = request.user
    roles = usuario.roles.all()
    permisosObjects = []
    permisos=[]
    for rolactual in roles:

        permisosObjects.extend(rolactual.permisos.all())
    for permisoObject in permisosObjects:
        permisos.append(permisoObject.nombre)
    return permisos



def obtenerPermisosSistema(request):
    usuario = request.user
    roles = usuario.roles.filter(tipo="SISTEMA")
    permisosObjects = []
    permisos=[]
    for rolactual in roles:

        permisosObjects.extend(rolactual.permisos.all())
    for permisoObject in permisosObjects:
        permisos.append(permisoObject.nombre)
    return permisos

def obtenerPermisosProyecto(request):
    usuario = request.user
    roles = usuario.roles.filter(tipo="PROYECTO")
    permisosObjects = []
    permisos=[]
    for rolactual in roles:

        permisosObjects.extend(rolactual.permisos.all())
    for permisoObject in permisosObjects:
        permisos.append(permisoObject.nombre)
    return permisos

def obtenerPermisosProyecto(request,codigo):
    usuario = request.user
    equipo = Equipo.objects.filter(usuario_id = usuario.id).filter(proyecto_id = codigo)
    permisosObjects = []
    permisos=[]
    for e in equipo:
        r = Rol.objects.get(pk = e.rol_id)
        permisosObjects.extend(r.permisos.all())
    for permisoObject in permisosObjects:
        permisos.append(permisoObject.nombre)
    return permisos

def administrar_usuario(request):
    permisos = obtenerPermisosSistema(request)
    return "crear usuario" in permisos or "modificar usuario" in permisos or "eliminar usuario" in permisos or "ver usuario" in permisos or "asignar rol sistema" in permisos or "cambiar estado usuario" in permisos or "asignar cliente a usuario" in permisos


def obtenerRolesAsignados(request, codigo):
    usuarios = User.objects.all()
    rolesObjects = []
    roles=[]
    for usuario in usuarios:
        rolesObjects.append(usuario.roles.all())
    for rolObject in rolesObjects:
        for r in rolObject:
            roles.append(r)
    return roles